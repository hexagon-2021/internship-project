# internship-project

Online food ordering platform
