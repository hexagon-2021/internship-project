<section class="dashboard_categorie" id="products">
  <h1 class="dashboard_section_title">Edito Profilin</h1>
</section> <!-- #products -->